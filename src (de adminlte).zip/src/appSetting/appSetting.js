import React, {Component} from 'react';

export const AppSetting = () => {
    return (
        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    );
  }