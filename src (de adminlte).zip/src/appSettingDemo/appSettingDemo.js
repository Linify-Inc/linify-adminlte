import React, {Component} from 'react';

export const AppSettingDemo = () => {
    return (
        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    );
  }